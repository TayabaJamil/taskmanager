package com.example.taskmanager.dto;


import lombok.Data;
import lombok.NonNull;

@Data
public class TaskRequest {
    private String title;
    private String description;
}
