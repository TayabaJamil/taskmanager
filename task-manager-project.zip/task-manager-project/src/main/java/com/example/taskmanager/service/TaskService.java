package com.example.taskmanager.service;

import com.example.taskmanager.entity.Task;
import java.util.List;

public interface TaskService {
    Task saveTask(Task task);
    List<Task> getAllTasks();
    Task getTaskById(Long id);
    Task updateTask(Long id, Task taskDetails);
    void deleteTask(Long id);// Specific task dhoondne ke liye
}